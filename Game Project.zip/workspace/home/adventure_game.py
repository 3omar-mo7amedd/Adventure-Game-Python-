import time
import random

def print_pause(text):
    time.sleep(1.5)
    print(text)
    
def adventure():
    """The game"""
    score = 0
    print_pause("Welcome to this adventure!!")
    while score < 40:
        print_pause("You find yourself in a large area.")
        print_pause("You find an old home and a cave.")
        print_pause("1. Enter the old home.")
        print_pause("2. Enter the cave.")
        
        choice = input("Pick 1 or 2: ")
        while choice not in ("1", "2"):
            print_pause("Invalid choice. Please pick 1 or 2.")
            choice = input("Pick 1 or 2: ")
            
        if choice == "1":
            score += random.randint(5, 10)
            score = old_home(score)
        elif choice == "2":
            score += random.randint(5, 10)
            score = cave(score)
    
        if score >= 40:
            break
        play_again = input("Do you want to play again? (yes or no): ").lower()
        while play_again not in ["yes", "no"]:
            print_pause("Invalid choice. Please enter 'yes' or 'no'.")
            play_again=input("Do you want to play again?(yes or no):").lower()
        if play_again == "no":
            break
    
    if score >= 40:
        print_pause("Congratulations! You've reached a score of 40 or more.")
        print_pause("You win!")
    else:
        print_pause("Thank you for playing! Goodbye!")

def old_home(score):
    """You are in the old home now"""
    print_pause("You are now in the old home.")
    print_pause("1. Knock on the door.")
    print_pause("2. Keep walking")
    
    door_choice = input("Enter 1 or 2: ")
    while door_choice not in ("1", "2"):
        print_pause("Invalid choice. Please enter 1 or 2.")
        door_choice = input("Enter 1 or 2: ")

    if door_choice == "1":
        print_pause("A big monster attacks you.")
        print_pause("The monster keeps running after you.")
        score += random.randint(15, 20)  # Random score increase.
        print_pause(f"Your current score: {score}")
        print_pause("1. You attack the monster.")
        print_pause("2. Keep running from the monster.")
        bear_choice = input("Enter 1 or 2: ")
        while bear_choice not in ("1", "2"):
            print_pause("Invalid choice. Please enter 1 or 2.")
            bear_choice = input("Enter 1 or 2: ")

        if bear_choice == "1":
            print_pause("You attack the monster and you die.")
            score -= random.randint(5, 15)  # Random score reduction
            print_pause(f"Your current score: {score}")
        elif bear_choice == "2":
            print_pause("You keep running.")
            print_pause("You find a chest.")
            print_pause("1. Open the chest.")
            print_pause("2. Don't open the chest.")
            chest_choice = input("Enter 1 or 2: ")
            while chest_choice not in ("1", "2"):
                print_pause("Invalid choice. Please enter 1 or 2.")
                chest_choice = input("Enter 1 or 2: ")
            if chest_choice == "1":
                print_pause("You find a gun.")
                print_pause("You use it to kill the monster.")
                score += random.randint(15, 20)  # Random score increase
                print_pause(f"Your current score: {score}")
                print_pause("Congratulations, You won.")
            elif chest_choice == "2":
                print_pause("The monster kills you.")
                score -= random.randint(5, 15)  # Random score reduction
                print_pause(f"Your current score: {score}")
    elif door_choice == "2":
        print_pause("You keep walking and you lost.")
        score -= random.randint(5, 15)  # Random score reduction.
        print_pause(f"Your current score: {score}")

    return score

def cave(score):
    """You entered the cave."""
    print_pause("You enter the cave.")
    print_pause("You find way on right and way on left.")
    print_pause("1. You go on right way.")
    print_pause("2. You go on left way.")
    way_choice = input("Enter 1 or 2: ")
    while way_choice not in ("1", "2"):
        print_pause("Invalid choice. Please enter 1 or 2.")
        way_choice = input("Enter 1 or 2: ")
    if way_choice == "1":
        print_pause("You enter the right way.")
        print_pause("You won!!")
        score += random.randint(15, 20)  # Random score increase.
        print_pause(f"Your current score: {score}")
    elif way_choice == "2":
        print_pause("You find a gun.")
        print_pause("You find two ways.")
        print_pause("1. Go left.")
        print_pause("2. Go right.")
        new_choice = input("Enter 1 or 2: ")
        while new_choice not in ("1", "2"):
            print_pause("Invalid choice. Please enter 1 or 2.")
            new_choice = input("Enter 1 or 2:")
        if new_choice == "1":
            print_pause("You find a bear.")
            print_pause("You kill the bear.")
            score += random.randint(15, 20)  # Random score increase.
            print_pause(f"Your current score: {score}")
            print_pause("Congratulations, you won!!")
        elif new_choice == "2":
            print_pause("A thief attacks you and kills you.")
            score -= random.randint(15, 20)  # Random score reduction.
            print_pause(f"Your current score: {score}")
            print_pause("You lost..")

    return score

adventure()